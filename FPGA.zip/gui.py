import tkinter as tk
from tkinter import messagebox, scrolledtext
import jit_executor  # Assuming jit_executor.run_all(expression, context) is defined

import tkinter as tk

class GradientFrame(tk.Canvas):
    def __init__(self, parent, color1, color2, **kwargs):
        super().__init__(parent, **kwargs)
        self.color1 = color1
        self.color2 = color2
        self.bind("<Configure>", self._draw_gradient)

    def _draw_gradient(self, event=None):
        self.delete("gradient")
        width = self.winfo_width()
        height = self.winfo_height()
        limit = height
        (r1, g1, b1) = self.winfo_rgb(self.color1)
        (r2, g2, b2) = self.winfo_rgb(self.color2)
        r_ratio = float(r2 - r1) / limit
        g_ratio = float(g2 - g1) / limit
        b_ratio = float(b2 - b1) / limit

        for i in range(limit):
            nr = int(r1 + (r_ratio * i))
            ng = int(g1 + (g_ratio * i))
            nb = int(b1 + (b_ratio * i))
            color = f'#{nr//256:02x}{ng//256:02x}{nb//256:02x}'
            self.create_line(0, i, width, i, tags=("gradient",), fill=color)
        self.lower("gradient")

class FrontPage(tk.Frame):
    def __init__(self, master, switch_callback):
        super().__init__(master)

        self.switch_callback = switch_callback
        self.pack_propagate(False)

        # Gradient background canvas
        self.gradient = GradientFrame(self, "#0f172a", "#2563eb")
        self.gradient.pack(fill="both", expand=True)

        # Container frame on top of gradient canvas
        container = tk.Frame(self.gradient, bg="#0f172a")
        container.place(relx=0.5, rely=0.5, anchor="center")

        # Title with shadow effect
        self.shadow1 = tk.Label(container, text="🔧 FPGA X JIT Compiler", font=("Segoe UI", 30, "bold"),
                                fg="#0a0a0a", bg="#0f172a")
        self.shadow1.place(x=3, y=3)
        self.title = tk.Label(container, text="🔧 FPGA X JIT Compiler", font=("Segoe UI", 30, "bold"),
                              fg="#10b981", bg="#0f172a")
        self.title.place(x=0, y=0)

        self.desc = tk.Label(container, text="Compile & Simulate Mathematical Expressions on FPGA-like backend",
                             font=("Segoe UI", 14), fg="#d1d5db", bg="#0f172a", wraplength=500, justify="center")
        self.desc.pack(pady=(70, 40))

        # Custom styled button with hover effect
        self.start_btn = tk.Button(container, text="🚀 Get Started", font=("Segoe UI", 16, "bold"),
                                   bg="#10b981", fg="white", activebackground="#059669",
                                   padx=25, pady=12, bd=0, cursor="hand2", command=self.animate_slide)
        self.start_btn.pack()

        # Hover effect bindings
        self.start_btn.bind("<Enter>", lambda e: self.start_btn.config(bg="#059669"))
        self.start_btn.bind("<Leave>", lambda e: self.start_btn.config(bg="#10b981"))

    def animate_slide(self):
        for x in range(0, 701, 20):
            self.place(x=-x, y=0)
            self.master.update()
            self.after(5)
        self.switch_callback()


class HoverButton(tk.Button):
    def __init__(self, master=None, **kwargs):
        super().__init__(master, **kwargs)
        self.default_bg = kwargs.get('bg', self.cget("background"))
        self.bind("<Enter>", self.on_enter)
        self.bind("<Leave>", self.on_leave)

    def on_enter(self, e):
        self['background'] = self._hover_bg if hasattr(self, '_hover_bg') else "#4ade80"

    def on_leave(self, e):
        self['background'] = self.default_bg


class MainAppPage(tk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self.master = master
        self.configure(bg="#f7fbff")

        self.dark_mode = tk.BooleanVar(value=False)
        theme_toggle = tk.Checkbutton(self, text="🌙 Dark Mode", variable=self.dark_mode, command=self.toggle_theme,
                                      bg="#f7fbff", font=("Segoe UI", 10))
        theme_toggle.pack(anchor='ne', padx=20, pady=(5, 0))

        tk.Label(self, text="🧮 Expression:", font=("Segoe UI", 12), bg="#f7fbff").pack(anchor='w', padx=20, pady=(10, 0))
        self.expr_entry = tk.Entry(self, width=80, font=("Segoe UI", 11), bg="#f1f5f9", relief=tk.FLAT)
        self.expr_entry.pack(padx=20, pady=5)
        self.add_focus_effect(self.expr_entry)

        tk.Label(self, text="🔢 Variables (e.g., a=2, b=5):", font=("Segoe UI", 12), bg="#f7fbff").pack(anchor='w', padx=20)
        self.vars_entry = tk.Entry(self, width=80, font=("Segoe UI", 11), bg="#f1f5f9", relief=tk.FLAT)
        self.vars_entry.pack(padx=20, pady=5)
        self.add_focus_effect(self.vars_entry)

        # Buttons with hover effect
        btn_frame = tk.Frame(self, bg="#f7fbff")
        btn_frame.pack(pady=15)

        self.run_btn = HoverButton(btn_frame, text="⚙️ Run JIT + Simulate", command=self.run_jit_sim,
                                   font=("Segoe UI", 11), bg="#2563eb", fg="white", activebackground="#1e40af",
                                   padx=12, pady=6)
        self.run_btn._hover_bg = "#1e40af"
        self.run_btn.grid(row=0, column=0, padx=10)

        self.clear_btn = HoverButton(btn_frame, text="🧹 Clear", command=self.clear_all,
                                     font=("Segoe UI", 11), bg="#f97316", fg="white", activebackground="#ea580c",
                                     padx=12, pady=6)
        self.clear_btn._hover_bg = "#ea580c"
        self.clear_btn.grid(row=0, column=1, padx=10)

        self.export_btn = HoverButton(btn_frame, text="💾 Export Output", command=self.export_output,
                                      font=("Segoe UI", 11), bg="#10b981", fg="white", activebackground="#059669",
                                      padx=12, pady=6)
        self.export_btn._hover_bg = "#059669"
        self.export_btn.grid(row=0, column=2, padx=10)

        tk.Label(self, text="📤 Output:", font=("Segoe UI", 12), bg="#f7fbff").pack(anchor='w', padx=20)
        self.output_text = scrolledtext.ScrolledText(self, width=85, height=20, font=("Consolas", 10),
                                                     bg="#f8fafc", fg="#0f172a", relief=tk.FLAT)
        self.output_text.pack(padx=20, pady=10)

        self.status_bar = tk.Label(self, text="Ready", bd=1, relief=tk.SUNKEN, anchor='w',
                                   font=("Segoe UI", 10), bg="#cbd5e1", fg="#1e293b")
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # Fade-in animation on showing page
        self.alpha = 0
        self.after(50, self.fade_in)

    def fade_in(self):
        if self.alpha < 1.0:
            self.alpha += 0.05
            self.master.attributes("-alpha", self.alpha)
            self.after(30, self.fade_in)
        else:
            self.master.attributes("-alpha", 1.0)

    def add_focus_effect(self, widget):
        def on_focus_in(event):
            widget.configure(highlightbackground="#2563eb", highlightcolor="#2563eb", highlightthickness=2)

        def on_focus_out(event):
            widget.configure(highlightthickness=0)

        widget.bind("<FocusIn>", on_focus_in)
        widget.bind("<FocusOut>", on_focus_out)

    def run_jit_sim(self):
        expr = self.expr_entry.get().strip()
        vars_input = self.vars_entry.get().strip()

        if not expr or not vars_input:
            messagebox.showwarning("Missing Input", "Please enter both expression and variables.")
            return

        try:
            context = {}
            for var in vars_input.split(','):
                k, v = var.strip().split('=')
                context[k.strip()] = int(v.strip())
        except Exception as e:
            messagebox.showerror("Variable Error", f"Invalid variable format: {e}")
            return

        try:
            result, ir_output, sim_output = jit_executor.run_all(expr, context)

            self.output_text.delete(1.0, tk.END)
            self.output_text.insert(tk.END, f"Result: {result}\n")
            self.output_text.insert(tk.END, "\n--- LLVM IR ---\n")
            self.output_text.insert(tk.END, ir_output)
            self.output_text.insert(tk.END, "\n--- FPGA Simulation ---\n")
            self.output_text.insert(tk.END, sim_output + "\n")

            self.status_transition("✅ Simulation Complete", "#bbf7d0")
        except Exception as e:
            messagebox.showerror("Execution Error", f"An error occurred: {e}")
            self.status_transition("❌ Simulation Failed", "#fecaca")

    def status_transition(self, text, color):
        # Smooth color transition for status bar bg
        self.status_bar.config(text=text)
        current_bg = self.status_bar.cget("bg")
        self._fade_color(self.status_bar, current_bg, color, steps=10)

    def _fade_color(self, widget, from_color, to_color, steps=10, step=0):
        # Hex to RGB
        def hex_to_rgb(h):
            h = h.lstrip("#")
            return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

        def rgb_to_hex(rgb):
            return "#" + "".join(f"{int(c):02x}" for c in rgb)

        fc = hex_to_rgb(from_color)
        tc = hex_to_rgb(to_color)
        ratio = step / steps
        new_color = tuple(fc[i] + (tc[i] - fc[i]) * ratio for i in range(3))
        widget.config(bg=rgb_to_hex(new_color))
        if step < steps:
            widget.after(40, lambda: self._fade_color(widget, from_color, to_color, steps, step + 1))

    def clear_all(self):
        self.expr_entry.delete(0, tk.END)
        self.vars_entry.delete(0, tk.END)
        self.output_text.delete(1.0, tk.END)
        self.status_transition("🔄 Cleared", "#cbd5e1")

    def export_output(self):
        content = self.output_text.get("1.0", tk.END).strip()
        if not content:
            messagebox.showinfo("No Output", "There is no output to export.")
            return

        try:
            with open("simulation_output.txt", "w") as f:
                f.write(content)
            self.status_transition("✅ Output saved as simulation_output.txt", "#4ade80")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save file: {e}")

    def toggle_theme(self):
        if self.dark_mode.get():
            self.smooth_bg_transition("#f7fbff", "#1e293b")
            self.configure(bg="#1e293b")
            self.status_bar.configure(fg="white")
            self.output_text.configure(bg="#0f172a", fg="#e2e8f0", insertbackground="white")
            self.expr_entry.configure(bg="#1e293b", fg="white", insertbackground="white")
            self.vars_entry.configure(bg="#1e293b", fg="white", insertbackground="white")
        else:
            self.smooth_bg_transition("#1e293b", "#f7fbff")
            self.configure(bg="#f7fbff")
            self.status_bar.configure(fg="#1e293b")
            self.output_text.configure(bg="#f8fafc", fg="#0f172a", insertbackground="black")
            self.expr_entry.configure(bg="#f1f5f9", fg="#000000", insertbackground="black")
            self.vars_entry.configure(bg="#f1f5f9", fg="#000000", insertbackground="black")

    def smooth_bg_transition(self, from_color, to_color, steps=20, step=0):
        def hex_to_rgb(h):
            h = h.lstrip("#")
            return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

        def rgb_to_hex(rgb):
            return "#" + "".join(f"{int(c):02x}" for c in rgb)

        fc = hex_to_rgb(from_color)
        tc = hex_to_rgb(to_color)
        ratio = step / steps
        new_color = tuple(fc[i] + (tc[i] - fc[i]) * ratio for i in range(3))
        self.configure(bg=rgb_to_hex(new_color))
        self.status_bar.configure(bg=rgb_to_hex(new_color))
        self.after(30, lambda: self.smooth_bg_transition(from_color, to_color, steps, step + 1) if step < steps else None)


class FPGAJITApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("FPGA X JIT Compiler")
        self.geometry("700x600")
        self.resizable(False, False)
        self.attributes("-alpha", 1.0)  # For fade-in control

        self.front_page = FrontPage(self, self.show_main_app)
        self.main_page = MainAppPage(self)

        self.front_page.place(x=0, y=0, relwidth=1, relheight=1)

    def show_main_app(self):
        self.front_page.place_forget()
        self.main_page.place(x=0, y=0, relwidth=1, relheight=1)
        self.attributes("-alpha", 0)  # Reset transparency before fade-in
        self.main_page.alpha = 0
        self.main_page.fade_in()


if __name__ == "__main__":
    app = FPGAJITApp()
    app.mainloop()
