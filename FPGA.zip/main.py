from llvmlite import binding
import ctypes
from parser import Parser
from jit_codegen import generate_code, symbol_table, builder, module
from fpgasim import FPGA_Simulator

# Initialize FPGA Simulator
simulator = FPGA_Simulator()

# Adding LUT with a sample truth table
simulator.add_lut('lut1', {'00': 0, '01': 1, '10': 1, '11': 0})

# Adding a Flip-Flop
simulator.add_flip_flop()

# Adding a Register of width 4
simulator.add_register(4)

# Simulate logic operations and update hardware components
print("--- FPGA Simulation ---")
simulator.execute()

# Sample expression to parse and execute
input_expr = "a + 3 * (b - 1)"
print("\n--- Expression Parsing and JIT Compilation ---")
print(f"Input Expression: {input_expr}")

# Tokenize input expression
tokens = input_expr.replace('(', ' ( ').replace(')', ' ) ').split()

# Parse the expression
parser = Parser(tokens)
ast = parser.parse()

# Create dummy variables in symbol_table
a_ptr = builder.alloca(builder.int_type, name="a")
builder.store(builder.int_type(10), a_ptr)
symbol_table['a'] = a_ptr

b_ptr = builder.alloca(builder.int_type, name="b")
builder.store(builder.int_type(5), b_ptr)
symbol_table['b'] = b_ptr

# Generate LLVM IR Code
generate_code(ast)

# Print the LLVM IR
print("\nGenerated LLVM IR:\n")
print(module)

# JIT Compilation and Execution
print("\n--- JIT Execution ---")
binding.initialize()
binding.initialize_native_target()
binding.initialize_native_asmprinter()

def create_execution_engine():
    target = binding.Target.from_default_triple()
    target_machine = target.create_target_machine()
    backing_mod = binding.parse_assembly("")
    engine = binding.create_mcjit_compiler(backing_mod, target_machine)
    return engine

engine = create_execution_engine()
mod = binding.parse_assembly(str(module))
mod.verify()
engine.add_module(mod)
engine.finalize_object()

# Get function pointer to 'main'
func_ptr = engine.get_function_address("main")
cfunc = ctypes.CFUNCTYPE(ctypes.c_int)(func_ptr)

# Execute the compiled function
result = cfunc()
print(f"\nExecution Result: {result}")