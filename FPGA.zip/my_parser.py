# parser.py

class NumberNode:
    def __init__(self, value):
        self.value = int(value)

    def __repr__(self):
        return f"NumberNode({self.value})"

class VariableNode:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return f"VariableNode('{self.name}')"

class BinaryOpNode:
    def __init__(self, left, op, right):
        self.left = left
        self.op = op  # '+', '-', '*', '/'
        self.right = right

    def __repr__(self):
        return f"BinaryOpNode({self.left}, '{self.op}', {self.right})"


class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self):
        # Returns the current token without advancing
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def consume(self, expected=None):
        # Returns current token and advances, optionally checks expected value
        if self.pos >= len(self.tokens):
            raise Exception("Unexpected end of input")
        current = self.tokens[self.pos]
        if expected and current != expected:
            raise Exception(f"Expected '{expected}', got '{current}'")
        self.pos += 1
        return current

    def parse(self):
        # Entry point for parsing expression
        node = self.expr()
        if self.pos < len(self.tokens):
            raise Exception("Unexpected token after expression")
        return node

    def expr(self):
        # Parse addition and subtraction
        node = self.term()

        while self.peek() in ('+', '-'):
            op = self.consume()
            right = self.term()
            node = BinaryOpNode(node, op, right)

        return node

    def term(self):
        # Parse multiplication and division
        node = self.factor()

        while self.peek() in ('*', '/'):
            op = self.consume()
            right = self.factor()
            node = BinaryOpNode(node, op, right)

        return node

    def factor(self):
        token = self.peek()

        if token is None:
            raise Exception("Unexpected end of input in factor")

        # Parentheses: '(' expr ')'
        if token == '(':
            self.consume('(')
            node = self.expr()
            self.consume(')')
            return node

        # Number
        if token.isdigit():
            self.consume()
            return NumberNode(token)

        # Variable (single alphabet letter)
        if token.isalpha():
            self.consume()
            return VariableNode(token)

        raise Exception(f"Unexpected token '{token}' in factor")


def tokenize(expression):
    # Simple tokenizer for expression strings
    tokens = []
    i = 0
    while i < len(expression):
        ch = expression[i]
        if ch.isspace():
            i += 1
            continue
        if ch in '+-*/()':
            tokens.append(ch)
            i += 1
        elif ch.isdigit():
            num = ch
            i += 1
            while i < len(expression) and expression[i].isdigit():
                num += expression[i]
                i += 1
            tokens.append(num)
        elif ch.isalpha():
            tokens.append(ch)
            i += 1
        else:
            raise Exception(f"Invalid character '{ch}' in input")
    return tokens


if __name__ == "__main__":
    # Quick test
    expr = input("Enter an expression (e.g. a + 3 * (b - 1)):\n")
    tokens = tokenize(expr)
    parser = Parser(tokens)
    ast = parser.parse()
    print("Parsed AST:", ast)
