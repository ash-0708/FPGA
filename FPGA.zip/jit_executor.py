from llvmlite import binding
import ctypes
from jit_codegen import create_module_with_ast
from my_parser import Parser, VariableNode, BinaryOpNode

# Initialize LLVM
binding.initialize()
binding.initialize_native_target()
binding.initialize_native_asmprinter()

def create_execution_engine():
    target = binding.Target.from_default_triple()
    target_machine = target.create_target_machine()
    backing_mod = binding.parse_assembly("")
    engine = binding.create_mcjit_compiler(backing_mod, target_machine)
    return engine

def compile_ir(engine, llvm_ir):
    mod = binding.parse_assembly(llvm_ir)
    mod.verify()
    engine.add_module(mod)
    engine.finalize_object()
    engine.run_static_constructors()
    return mod

def extract_variables(node, vars_set):
    if isinstance(node, VariableNode):
        vars_set.add(node.name)
    elif isinstance(node, BinaryOpNode):
        extract_variables(node.left, vars_set)
        extract_variables(node.right, vars_set)

def run_all(expr, context):
    """
    expr: str => arithmetic expression like 'a + 3 * (b - 1)'
    context: dict => variable mapping like {'a': 3, 'b': 5}

    returns: tuple => (result: int, llvm_ir: str, sim_output: str)
    """
    # 1. Tokenize & parse expression string into AST
    tokens = expr.replace('(', ' ( ').replace(')', ' ) ').split()
    parser = Parser(tokens)
    ast_root = parser.parse()

    # 2. Extract variables from AST and check for missing
    variables = set()
    extract_variables(ast_root, variables)

    missing = variables - context.keys()
    if missing:
        raise ValueError(f"Missing variable values: {missing}")

    # 3. Generate LLVM IR module from AST
    llvm_module = create_module_with_ast(ast_root, context)
    llvm_ir = str(llvm_module)

    # 4. Create engine & compile IR
    engine = create_execution_engine()
    compile_ir(engine, llvm_ir)

    # 5. Get function pointer and cast to callable C function
    func_ptr = engine.get_function_address("main")
    cfunc = ctypes.CFUNCTYPE(ctypes.c_int)(func_ptr)

    # 6. Execute and return result
    result = cfunc()

    # 7. Sim output (placeholder)
    sim_output = f"Simulated output matches JIT result: {result}"

    return result, llvm_ir, sim_output
