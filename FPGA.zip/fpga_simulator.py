# FPGA Components Simulation in Python

# --- LUT (Look-Up Table) Class ---
class LUT:
    def __init__(self, lut_dict, input_width):
        self.lut_dict = lut_dict  # Dictionary mapping binary input to output
        self.input_width = input_width

    def evaluate(self, inputs):
        # Check if input length matches LUT width
        if len(inputs) != self.input_width:
            raise ValueError(f"Input width mismatch for LUT: expected {self.input_width}, got {len(inputs)}")
        key = ''.join(str(bit) for bit in inputs)  # Convert input bits to string
        return self.lut_dict.get(key, 0)  # Return output or default to 0

# --- Flip-Flop Class (D-type) ---
class FlipFlop:
    def __init__(self):
        self.state = 0  # Initial state

    def clock(self, input_signal):
        self.state = input_signal  # On clock, input becomes new state

    def read(self):
        return self.state  # Return stored state

# --- Register Class ---
class Register:
    def __init__(self, width):
        self.width = width
        self.value = [0] * width  # Initialize with zeros

    def load(self, input_value):
        if len(input_value) != self.width:
            raise ValueError(f"Input width mismatch for Register: expected {self.width}, got {len(input_value)}")
        self.value = list(input_value)  # Store input value

    def read(self):
        return self.value  # Return stored value

# --- Logic Gate Classes ---
class ANDGate:
    @staticmethod
    def evaluate(a, b):
        return a & b

class ORGate:
    @staticmethod
    def evaluate(a, b):
        return a | b

class XORGate:
    @staticmethod
    def evaluate(a, b):
        return a ^ b

class NOTGate:
    @staticmethod
    def evaluate(a):
        return 0 if a else 1

# --- FPGA Simulator Main Class ---
class FPGA_Simulator:
    def __init__(self):
        self.luts = {}           # Dictionary to hold LUTs
        self.flip_flops = []     # List of flip-flops
        self.registers = []      # List of registers
        self.gates = {           # Supported logic gates
            'AND': ANDGate,
            'OR': ORGate,
            'XOR': XORGate,
            'NOT': NOTGate
        }

    def add_lut(self, name, lut_dict, input_width):
        self.luts[name] = LUT(lut_dict, input_width)  # Add new LUT

    def add_flip_flop(self):
        ff = FlipFlop()
        self.flip_flops.append(ff)
        return ff  # Return for reference

    def add_register(self, width):
        reg = Register(width)
        self.registers.append(reg)
        return reg

    def simulate_logic(self, gate_type, *inputs):
        gate = self.gates.get(gate_type)
        if not gate:
            raise ValueError(f"Unsupported gate type: {gate_type}")

        # Handle NOT gate with one input
        if gate_type == 'NOT':
            if len(inputs) != 1:
                raise ValueError("NOT gate requires exactly one input")
            return gate.evaluate(inputs[0])
        else:
            # Handle gates like AND, OR, XOR with two inputs
            if len(inputs) != 2:
                raise ValueError(f"{gate_type} gate requires exactly two inputs")
            return gate.evaluate(inputs[0], inputs[1])

    def execute(self):
        print("=== FPGA Simulation Start ===")

        # Simulate LUT evaluation
        lut_output = self.luts['lut1'].evaluate([1, 0])
        print(f"LUT Output for input [1,0]: {lut_output}")

        # Clock flip-flop with LUT output
        self.flip_flops[0].clock(lut_output)
        print(f"Flip-Flop State after clock: {self.flip_flops[0].read()}")

        # Load 4-bit value into register
        self.registers[0].load([1, 0, 1, 0])
        print(f"Register Value loaded: {self.registers[0].read()}")

        # Logic gate operations
        a, b = 1, 0
        print(f"AND Gate {a} & {b} = {self.simulate_logic('AND', a, b)}")
        print(f"OR Gate {a} | {b} = {self.simulate_logic('OR', a, b)}")
        print(f"XOR Gate {a} ^ {b} = {self.simulate_logic('XOR', a, b)}")
        print(f"NOT Gate ~{a} = {self.simulate_logic('NOT', a)}")

        print("=== FPGA Simulation End ===")

# --- Run Simulation if Script is Main ---
if __name__ == "__main__":
    sim = FPGA_Simulator()

    # Add LUT: 'lut1' with 2-bit input
    sim.add_lut('lut1', {'00': 0, '01': 1, '10': 1, '11': 0}, input_width=2)

    # Add components
    sim.add_flip_flop()   # Add one flip-flop
    sim.add_register(4)   # Add one 4-bit register

    # Run the simulation
    sim.execute()
